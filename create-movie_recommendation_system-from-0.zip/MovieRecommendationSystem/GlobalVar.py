import tkinter as tk
#全局变量
userid = 1
BigWindow = tk.Tk()


#data的位置
pathmovie = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/movies.csv"
pathlink = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/links.csv"
pathrating = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/ratings.csv"
pathcosSim_svd = r"D:/school/cosSim.pickle"#pickle
pathmovie_similar_svd = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/movie_similar_svd.csv"
pathoffline_recommend_svd = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/offline_recommend_svd.csv"
pathoffline_recommend_als = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/offline_recommend_als.csv"
pathmovie_similar_svd =r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/movie_similar_svd.csv"
pathmovie_similar_als = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/movie_similar_als.csv"
pathusers = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/users.csv"

pathonline_recommend = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/online_recommend.csv"

pathmovieidlist = r"C:/Users/asongredmi/Desktop/mvc/create-movie_recommendation_system-from-0/MovieRecommendationSystem/data/movieidlist.pickle"



